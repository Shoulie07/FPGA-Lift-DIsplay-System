/* Quartus Prime Version 25.1std.0 Build 1129 10/21/2025 SC Lite Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EP4CE6E22) Path("C:/Users/JAHAN/AppData/Local/quartus/Poject_UAS/output_files/") File("Lift_Display_Sistem.sof") MfrSpec(OpMask(1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
