// ============================================================
// Module  : clk_divider
// Fungsi  : Membagi clock 50MHz menjadi 1Hz dan 1kHz
// ============================================================
module clk_divider (
    input  wire clk_50mhz,
    output reg  clk_1hz,
    output reg  clk_1khz
);
    reg [25:0] cnt_1hz;
    reg [15:0] cnt_1khz;

    initial begin
        clk_1hz  = 0;
        clk_1khz = 0;
        cnt_1hz  = 0;
        cnt_1khz = 0;
    end

    always @(posedge clk_50mhz) begin
        // 1Hz : toggle setiap 25.000.000 siklus
        if (cnt_1hz == 26'd24_999_999) begin
            cnt_1hz <= 0;
            clk_1hz <= ~clk_1hz;
        end else begin
            cnt_1hz <= cnt_1hz + 1;
        end

        // 1kHz : toggle setiap 25.000 siklus (untuk scanning dot matrix)
        if (cnt_1khz == 16'd24_999) begin
            cnt_1khz <= 0;
            clk_1khz <= ~clk_1khz;
        end else begin
            cnt_1khz <= cnt_1khz + 1;
        end
    end

endmodule
