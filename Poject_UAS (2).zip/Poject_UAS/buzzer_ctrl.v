// ============================================================
// Module  : buzzer_ctrl
// Fungsi  : Membunyikan buzzer selama 1 detik
//           dengan suara lebih keras
// ============================================================
module buzzer_ctrl (
    input  wire clk,        // clock 50 MHz
    input  wire clk_1hz,    // timer detik
    input  wire trigger,    // trigger dari FSM
    output reg  buzzer
);

    // ========================================================
    // Register Internal
    // ========================================================
    reg active;

    reg [15:0] tone_cnt;

    initial begin
        active   = 1'b0;
        tone_cnt = 16'd0;
        buzzer   = 1'b0;
    end

    // ========================================================
    // Timer durasi buzzer 1 detik
    // ========================================================
    always @(posedge clk_1hz) begin

        // Mulai bunyi
        if (trigger) begin
            active <= 1'b1;
        end

        // Setelah 1 detik langsung mati
        else begin
            active <= 1'b0;
        end
    end

    // ========================================================
    // Generator suara buzzer
    // ========================================================
    always @(posedge clk) begin

        if (active) begin

            // Frekuensi suara buzzer
            if (tone_cnt >= 16'd12500) begin
                tone_cnt <= 16'd0;
                buzzer   <= ~buzzer;
            end
            else begin
                tone_cnt <= tone_cnt + 16'd1;
            end

        end
        else begin
            tone_cnt <= 16'd0;
            buzzer   <= 1'b0;
        end
    end

endmodule