// ============================================================
// Module  : floor_tracker
// Fungsi  : Melacak posisi lantai lift saat ini (lantai 1-4)
//           Update posisi hanya saat lift selesai bergerak
// ============================================================
module floor_tracker (
    input  wire       clk_1hz,
    input  wire       move_up_done,    // pulsa 1 siklus saat naik selesai
    input  wire       move_down_done,  // pulsa 1 siklus saat turun selesai
    output reg  [2:0] floor            // posisi lantai: 1,2,3,4
);
    initial floor = 3'd1;

    always @(posedge clk_1hz) begin
        if (move_up_done && floor < 3'd4)
            floor <= floor + 3'd1;
        else if (move_down_done && floor > 3'd1)
            floor <= floor - 3'd1;
    end

endmodule
