// ============================================================
// Module  : lift_top (v2)
// Fungsi  : Top level — menghubungkan semua sub-modul
//           Push button: Active LOW
//           Dot matrix : Common Cathode
// ============================================================
module lift_top (
    input  wire clk,

    // Push button Active LOW
    input  wire btn_up_raw,
    input  wire btn_down_raw,
    input  wire btn_open_raw,
    input  wire btn_close_raw,

    // Dot matrix Common Cathode
    output wire [7:0] row,    // ROW aktif LOW
    output wire [7:0] col,    // COL aktif HIGH

    // Buzzer
    output wire buzzer
);

    // --------------------------------------------------------
    // Wire internal
    // --------------------------------------------------------
    wire        clk_1hz;
    wire        clk_1khz;

    wire        btn_up;
    wire        btn_down;
    wire        btn_open;
    wire        btn_close;

    wire [2:0]  state;
    wire [4:0]  frame_addr;
    wire        move_up_done;
    wire        move_down_done;
    wire        buzz_trigger;
    wire [2:0]  floor;

    wire [7:0]  bmp_row0, bmp_row1, bmp_row2, bmp_row3;
    wire [7:0]  bmp_row4, bmp_row5, bmp_row6, bmp_row7;

    // --------------------------------------------------------
    // Clock Divider
    // --------------------------------------------------------
    clk_divider u_clk (
        .clk_50mhz (clk),
        .clk_1hz   (clk_1hz),
        .clk_1khz  (clk_1khz)
    );

    // --------------------------------------------------------
    // Debounce — Active LOW push button
    // btn_pulse keluar sebagai Active HIGH
    // --------------------------------------------------------
    // --------------------------------------------------------
// Debounce — Active LOW push button
// Output HIGH selama tombol ditekan
// --------------------------------------------------------
		debounce u_deb_up (
			 .clk     (clk),
			 .btn_in  (btn_up_raw),
			 .btn_out (btn_up)
		);

		debounce u_deb_down (
			 .clk     (clk),
			 .btn_in  (btn_down_raw),
			 .btn_out (btn_down)
		);

		debounce u_deb_open (
			 .clk     (clk),
			 .btn_in  (btn_open_raw),
			 .btn_out (btn_open)
		);

		debounce u_deb_close (
			 .clk     (clk),
			 .btn_in  (btn_close_raw),
			 .btn_out (btn_close)
		);

    // --------------------------------------------------------
    // Floor Tracker
    // --------------------------------------------------------
    floor_tracker u_floor (
        .clk_1hz        (clk_1hz),
        .move_up_done   (move_up_done),
        .move_down_done (move_down_done),
        .floor          (floor)
    );

    // --------------------------------------------------------
    // FSM Lift
    // --------------------------------------------------------
    fsm_lift u_fsm (
        .clk_1hz        (clk_1hz),
        .btn_up         (btn_up),
        .btn_down       (btn_down),
        .btn_open       (btn_open),
        .btn_close      (btn_close),
        .state          (state),
        .frame_addr     (frame_addr),
        .move_up_done   (move_up_done),
        .move_down_done (move_down_done),
        .buzz_trigger   (buzz_trigger),
        .floor          (floor)
    );

    // --------------------------------------------------------
    // Buzzer Controller
    // --------------------------------------------------------
    buzzer_ctrl u_buzz (
    .clk      (clk),
    .clk_1hz  (clk_1hz),
    .trigger  (buzz_trigger),
    .buzzer   (buzzer)
);

    // --------------------------------------------------------
    // Frame ROM
    // --------------------------------------------------------
    frame_rom u_rom (
        .addr (frame_addr),
        .row0 (bmp_row0),
        .row1 (bmp_row1),
        .row2 (bmp_row2),
        .row3 (bmp_row3),
        .row4 (bmp_row4),
        .row5 (bmp_row5),
        .row6 (bmp_row6),
        .row7 (bmp_row7)
    );

    // --------------------------------------------------------
    // Dot Matrix Driver — Common Cathode
    // --------------------------------------------------------
    dotmatrix_driver u_dot (
        .clk_1khz (clk_1khz),
        .row0     (bmp_row0),
        .row1     (bmp_row1),
        .row2     (bmp_row2),
        .row3     (bmp_row3),
        .row4     (bmp_row4),
        .row5     (bmp_row5),
        .row6     (bmp_row6),
        .row7     (bmp_row7),
        .row_sel  (row),
        .col_data (col)
    );

endmodule
