// ============================================================
// Module  : fsm_lift
// Fungsi  : State Machine utama sistem lift
//
// Alur kerja:
//   IDLE        → tampil angka lantai saat ini
//   DOOR_OPENING→ animasi buka pintu (4 frame x 1 detik)
//   DOOR_OPEN   → pintu terbuka, tampil angka lantai, tunggu input
//   DOOR_CLOSING→ animasi tutup pintu (4 frame x 1 detik)
//   MOVING_UP   → animasi panah naik (4 detik), lalu kembali IDLE
//   MOVING_DOWN → animasi panah turun (4 detik), lalu kembali IDLE
//
// Prioritas tombol saat DOOR_OPEN:
//   BTN_UP > BTN_DOWN > BTN_CLOSE
// ============================================================
module fsm_lift (
    input  wire       clk_1hz,
    input  wire       btn_up,          // pulsa bersih dari debounce
    input  wire       btn_down,        // pulsa bersih dari debounce
    input  wire       btn_open,        // pulsa bersih dari debounce
    input  wire       btn_close,       // pulsa bersih dari debounce

    output reg  [2:0] state,           // state aktif
    output reg  [4:0] frame_addr,      // alamat frame ROM
    output reg        move_up_done,    // pulsa saat selesai naik
    output reg        move_down_done,  // pulsa saat selesai turun
    output reg        buzz_trigger,    // pulsa aktifkan buzzer
    input  wire [2:0] floor            // posisi lantai saat ini dari floor_tracker
);
    // --------------------------------------------------------
    // Definisi State
    // --------------------------------------------------------
    parameter IDLE         = 3'd0;
    parameter DOOR_OPENING = 3'd1;
    parameter DOOR_OPEN    = 3'd2;
    parameter DOOR_CLOSING = 3'd3;
    parameter MOVING_UP    = 3'd4;
    parameter MOVING_DOWN  = 3'd5;

    // --------------------------------------------------------
    // Register Internal
    // --------------------------------------------------------
    reg [2:0] timer;         // countdown detik per state
    reg [1:0] anim_frame;    // frame animasi saat ini (0-3)
    reg       pending_up;    // flag: tombol naik ditekan saat pintu terbuka
    reg       pending_down;  // flag: tombol turun ditekan saat pintu terbuka

    initial begin
        state         = IDLE;
        frame_addr    = 5'd0;
        move_up_done  = 0;
        move_down_done= 0;
        buzz_trigger  = 0;
        timer         = 0;
        anim_frame    = 0;
        pending_up    = 0;
        pending_down  = 0;
    end

    // --------------------------------------------------------
    // Fungsi Pemilih Alamat Frame
    // --------------------------------------------------------
    // Lantai 1-4 → addr 0-3
    // Panah naik frame 0-3 → addr 4-7
    // Panah turun frame 0-3 → addr 8-11
    // Pintu buka frame 0-3 → addr 12-15
    // Pintu tutup frame 0-3 → addr 16-19

    // --------------------------------------------------------
    // FSM Utama
    // --------------------------------------------------------
    always @(posedge clk_1hz) begin
        // Default: sinyal pulsa selalu 0 kecuali di-set eksplisit
        move_up_done   <= 1'b0;
        move_down_done <= 1'b0;
        buzz_trigger   <= 1'b0;

        case (state)

            // --------------------------------------------
            // IDLE: Tampilkan angka lantai saat ini
            // Menunggu input tombol apapun
            // --------------------------------------------
            IDLE: begin
                anim_frame <= 2'd0;
                // Tampilkan angka lantai (floor 1=addr0, 2=addr1, dst)
                frame_addr <= {2'b00, floor - 3'd1};

                if (btn_up && floor < 3'd4) begin
                    // Langsung mulai naik
                    state      <= MOVING_UP;
                    timer      <= 3'd3;   // 4 detik: 3,2,1,0
                    anim_frame <= 2'd0;
                    frame_addr <= 5'd4;   // panah naik frame 0
                end
                else if (btn_down && floor > 3'd1) begin
                    // Langsung mulai turun
                    state      <= MOVING_DOWN;
                    timer      <= 3'd3;
                    anim_frame <= 2'd0;
                    frame_addr <= 5'd8;   // panah turun frame 0
                end
                else if (btn_open) begin
                    // Mulai buka pintu
                    state      <= DOOR_OPENING;
                    timer      <= 3'd3;
                    anim_frame <= 2'd0;
                    frame_addr <= 5'd12;  // pintu buka frame 0
                end
            end

            // --------------------------------------------
            // DOOR_OPENING: Animasi buka pintu (4 frame)
            // Setiap detik ganti frame, selesai → DOOR_OPEN
            // --------------------------------------------
            DOOR_OPENING: begin
                if (timer == 3'd0) begin
                    // Animasi buka selesai → masuk DOOR_OPEN
                    state      <= DOOR_OPEN;
                    frame_addr <= {2'b00, floor - 3'd1}; // kembali tampil angka lantai
                end else begin
                    // Maju ke frame berikutnya setiap detik
                    timer      <= timer - 3'd1;
                    anim_frame <= anim_frame + 2'd1;
                    frame_addr <= 5'd12 + {3'b000, (anim_frame + 2'd1)};
                end
            end

            // --------------------------------------------
            // DOOR_OPEN: Pintu terbuka
            // Tampil angka lantai, tunggu BTN_UP/DOWN/CLOSE
            // Prioritas: BTN_UP > BTN_DOWN > BTN_CLOSE
            // --------------------------------------------
            DOOR_OPEN: begin
                // Selalu tampil angka lantai saat pintu terbuka
                frame_addr <= {2'b00, floor - 3'd1};
                anim_frame <= 2'd0;

                // Rekam permintaan naik/turun
                if (btn_up && floor < 3'd4)
                    pending_up <= 1'b1;
                if (btn_down && floor > 3'd1)
                    pending_down <= 1'b1;

                // Eksekusi aksi berdasarkan prioritas
                if (btn_up && floor < 3'd4) begin
                    // Langsung tutup pintu lalu naik
                    pending_up   <= 1'b0;
                    pending_down <= 1'b0;
                    state        <= DOOR_CLOSING;
                    timer        <= 3'd3;
                    anim_frame   <= 2'd0;
                    frame_addr   <= 5'd16; // pintu tutup frame 0
                end
                else if (btn_down && floor > 3'd1) begin
                    pending_up   <= 1'b0;
                    pending_down <= 1'b0;
                    state        <= DOOR_CLOSING;
                    timer        <= 3'd3;
                    anim_frame   <= 2'd0;
                    frame_addr   <= 5'd16;
                end
                else if (btn_close) begin
                    pending_up   <= 1'b0;
                    pending_down <= 1'b0;
                    state        <= DOOR_CLOSING;
                    timer        <= 3'd3;
                    anim_frame   <= 2'd0;
                    frame_addr   <= 5'd16; // pintu tutup frame 0
                end
            end

            // --------------------------------------------
            // DOOR_CLOSING: Animasi tutup pintu (4 frame)
            // Selesai → cek pending naik/turun atau kembali IDLE
            // --------------------------------------------
            DOOR_CLOSING: begin
                if (timer == 3'd0) begin
                    // Animasi tutup selesai
                    if (pending_up && floor < 3'd4) begin
                        // Ada permintaan naik yang tertunda
                        pending_up <= 1'b0;
                        state      <= MOVING_UP;
                        timer      <= 3'd3;
                        anim_frame <= 2'd0;
                        frame_addr <= 5'd4;
                    end
                    else if (pending_down && floor > 3'd1) begin
                        // Ada permintaan turun yang tertunda
                        pending_down <= 1'b0;
                        state        <= MOVING_DOWN;
                        timer        <= 3'd3;
                        anim_frame   <= 2'd0;
                        frame_addr   <= 5'd8;
                    end
                    else begin
                        // Tidak ada permintaan → kembali IDLE
                        state      <= IDLE;
                        frame_addr <= {2'b00, floor - 3'd1};
                    end
                end else begin
                    // Maju ke frame berikutnya setiap detik
                    timer      <= timer - 3'd1;
                    anim_frame <= anim_frame + 2'd1;
                    frame_addr <= 5'd16 + {3'b000, (anim_frame + 2'd1)};
                end
            end

            // --------------------------------------------
            // MOVING_UP: Animasi panah naik (4 detik)
            // Setiap detik ganti frame, selesai → IDLE + naik 1 lantai
            // --------------------------------------------
            MOVING_UP: begin
                if (timer == 3'd0) begin
                    // Selesai naik
                    move_up_done <= 1'b1;   // update floor_tracker
                    buzz_trigger <= 1'b1;   // bunyikan buzzer
                    state        <= IDLE;
                    // floor_tracker belum update di clock ini,
                    // frame_addr diupdate di IDLE berikutnya
                    frame_addr   <= {2'b00, floor - 3'd1 + 3'd1}; // anticipate +1
                end else begin
                    timer      <= timer - 3'd1;
                    anim_frame <= anim_frame + 2'd1;
                    // Loop animasi frame 0-3 (addr 4-7)
                    frame_addr <= 5'd4 + {3'b000, (anim_frame + 2'd1) & 2'b11};
                end
            end

            // --------------------------------------------
            // MOVING_DOWN: Animasi panah turun (4 detik)
            // Setiap detik ganti frame, selesai → IDLE + turun 1 lantai
            // --------------------------------------------
            MOVING_DOWN: begin
                if (timer == 3'd0) begin
                    // Selesai turun
                    move_down_done <= 1'b1;
                    buzz_trigger   <= 1'b1;
                    state          <= IDLE;
                    frame_addr     <= {2'b00, floor - 3'd1 - 3'd1}; // anticipate -1
                end else begin
                    timer      <= timer - 3'd1;
                    anim_frame <= anim_frame + 2'd1;
                    // Loop animasi frame 0-3 (addr 8-11)
                    frame_addr <= 5'd8 + {3'b000, (anim_frame + 2'd1) & 2'b11};
                end
            end

            default: begin
                state      <= IDLE;
                frame_addr <= 5'd0;
            end
        endcase
    end

endmodule
