// ============================================================
// Module  : frame_rom
// Fungsi  : Menyimpan semua pola bitmap 8x8 untuk animasi
// Revisi  : Auto mirror horizontal agar tampilan benar di hardware
// ============================================================
module frame_rom (
    input  wire [4:0]  addr,
    output reg  [7:0]  row0,
    output reg  [7:0]  row1,
    output reg  [7:0]  row2,
    output reg  [7:0]  row3,
    output reg  [7:0]  row4,
    output reg  [7:0]  row5,
    output reg  [7:0]  row6,
    output reg  [7:0]  row7
);

    // ========================================================
    // Fungsi mirror horizontal 8-bit
    // ========================================================
    function [7:0] mirror8;
        input [7:0] data;
        begin
            mirror8 = {
                data[0],
                data[1],
                data[2],
                data[3],
                data[4],
                data[5],
                data[6],
                data[7]
            };
        end
    endfunction

    always @(*) begin
        case (addr)

            // =================================================
            // LANTAI 1
            // =================================================
            5'd0: begin
                row0 = mirror8(8'b00011000);
                row1 = mirror8(8'b00111000);
                row2 = mirror8(8'b00011000);
                row3 = mirror8(8'b00011000);
                row4 = mirror8(8'b00011000);
                row5 = mirror8(8'b00011000);
                row6 = mirror8(8'b01111110);
                row7 = mirror8(8'b00000000);
            end

            // =================================================
            // LANTAI 2
            // =================================================
            5'd1: begin
                row0 = mirror8(8'b00111100);
                row1 = mirror8(8'b01100110);
                row2 = mirror8(8'b00000110);
                row3 = mirror8(8'b00001100);
                row4 = mirror8(8'b00011000);
                row5 = mirror8(8'b00110000);
                row6 = mirror8(8'b01111110);
                row7 = mirror8(8'b00000000);
            end

            // =================================================
            // LANTAI 3
            // =================================================
            5'd2: begin
                row0 = mirror8(8'b00111100);
                row1 = mirror8(8'b01100110);
                row2 = mirror8(8'b00000110);
                row3 = mirror8(8'b00011100);
                row4 = mirror8(8'b00000110);
                row5 = mirror8(8'b01100110);
                row6 = mirror8(8'b00111100);
                row7 = mirror8(8'b00000000);
            end

            // =================================================
            // LANTAI 4
            // =================================================
            5'd3: begin
                row0 = mirror8(8'b00001100);
                row1 = mirror8(8'b00011100);
                row2 = mirror8(8'b00101100);
                row3 = mirror8(8'b01001100);
                row4 = mirror8(8'b01111110);
                row5 = mirror8(8'b00001100);
                row6 = mirror8(8'b00001100);
                row7 = mirror8(8'b00000000);
            end

           // =================================================
// PANAH NAIK (REVERSE)
// =================================================
5'd4: begin
    row0 = mirror8(8'b00000000);
    row1 = mirror8(8'b00000000);
    row2 = mirror8(8'b00000000);
    row3 = mirror8(8'b00011000);
    row4 = mirror8(8'b00111100);
    row5 = mirror8(8'b01111110);
    row6 = mirror8(8'b00011000);
    row7 = mirror8(8'b00000000);
end

5'd5: begin
    row0 = mirror8(8'b00000000);
    row1 = mirror8(8'b00000000);
    row2 = mirror8(8'b00011000);
    row3 = mirror8(8'b00111100);
    row4 = mirror8(8'b01111110);
    row5 = mirror8(8'b00011000);
    row6 = mirror8(8'b00011000);
    row7 = mirror8(8'b00000000);
end

5'd6: begin
    row0 = mirror8(8'b00000000);
    row1 = mirror8(8'b00011000);
    row2 = mirror8(8'b00111100);
    row3 = mirror8(8'b01111110);
    row4 = mirror8(8'b00011000);
    row5 = mirror8(8'b00011000);
    row6 = mirror8(8'b00011000);
    row7 = mirror8(8'b00000000);
end

5'd7: begin
    row0 = mirror8(8'b00011000);
    row1 = mirror8(8'b00111100);
    row2 = mirror8(8'b01111110);
    row3 = mirror8(8'b00011000);
    row4 = mirror8(8'b00011000);
    row5 = mirror8(8'b00011000);
    row6 = mirror8(8'b00000000);
    row7 = mirror8(8'b00000000);
end

            // =================================================
            // PANAH TURUN
            // =================================================
            5'd8: begin
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00011000);
                row2 = mirror8(8'b00011000);
                row3 = mirror8(8'b01111110);
                row4 = mirror8(8'b00111100);
                row5 = mirror8(8'b00011000);
                row6 = mirror8(8'b00000000);
                row7 = mirror8(8'b00000000);
            end

            5'd9: begin
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00000000);
                row2 = mirror8(8'b00011000);
                row3 = mirror8(8'b00011000);
                row4 = mirror8(8'b01111110);
                row5 = mirror8(8'b00111100);
                row6 = mirror8(8'b00011000);
                row7 = mirror8(8'b00000000);
            end

            5'd10: begin
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00000000);
                row2 = mirror8(8'b00000000);
                row3 = mirror8(8'b00011000);
                row4 = mirror8(8'b00011000);
                row5 = mirror8(8'b01111110);
                row6 = mirror8(8'b00111100);
                row7 = mirror8(8'b00011000);
            end

            5'd11: begin
                row0 = mirror8(8'b00011000);
                row1 = mirror8(8'b00011000);
                row2 = mirror8(8'b00000000);
                row3 = mirror8(8'b00000000);
                row4 = mirror8(8'b00011000);
                row5 = mirror8(8'b00011000);
                row6 = mirror8(8'b01111110);
                row7 = mirror8(8'b00111100);
            end

            // =================================================
            // PINTU BUKA
            // =================================================
            5'd12: begin
                row0 = mirror8(8'b11100111);
                row1 = mirror8(8'b11100111);
                row2 = mirror8(8'b11100111);
                row3 = mirror8(8'b11100111);
                row4 = mirror8(8'b11100111);
                row5 = mirror8(8'b11100111);
                row6 = mirror8(8'b11100111);
                row7 = mirror8(8'b11111111);
            end

            5'd13: begin
                row0 = mirror8(8'b11000011);
                row1 = mirror8(8'b11000011);
                row2 = mirror8(8'b11000011);
                row3 = mirror8(8'b11000011);
                row4 = mirror8(8'b11000011);
                row5 = mirror8(8'b11000011);
                row6 = mirror8(8'b11000011);
                row7 = mirror8(8'b11111111);
            end

            5'd14: begin
                row0 = mirror8(8'b10000001);
                row1 = mirror8(8'b10000001);
                row2 = mirror8(8'b10000001);
                row3 = mirror8(8'b10000001);
                row4 = mirror8(8'b10000001);
                row5 = mirror8(8'b10000001);
                row6 = mirror8(8'b10000001);
                row7 = mirror8(8'b11111111);
            end

            5'd15: begin
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00000000);
                row2 = mirror8(8'b00000000);
                row3 = mirror8(8'b00000000);
                row4 = mirror8(8'b00000000);
                row5 = mirror8(8'b00000000);
                row6 = mirror8(8'b00000000);
                row7 = mirror8(8'b11111111);
            end

            // =================================================
            // PINTU TUTUP
            // =================================================
            5'd16: begin
                row0 = mirror8(8'b00000000);
                row1 = mirror8(8'b00000000);
                row2 = mirror8(8'b00000000);
                row3 = mirror8(8'b00000000);
                row4 = mirror8(8'b00000000);
                row5 = mirror8(8'b00000000);
                row6 = mirror8(8'b00000000);
                row7 = mirror8(8'b11111111);
            end

            5'd17: begin
                row0 = mirror8(8'b10000001);
                row1 = mirror8(8'b10000001);
                row2 = mirror8(8'b10000001);
                row3 = mirror8(8'b10000001);
                row4 = mirror8(8'b10000001);
                row5 = mirror8(8'b10000001);
                row6 = mirror8(8'b10000001);
                row7 = mirror8(8'b11111111);
            end

            5'd18: begin
                row0 = mirror8(8'b11000011);
                row1 = mirror8(8'b11000011);
                row2 = mirror8(8'b11000011);
                row3 = mirror8(8'b11000011);
                row4 = mirror8(8'b11000011);
                row5 = mirror8(8'b11000011);
                row6 = mirror8(8'b11000011);
                row7 = mirror8(8'b11111111);
            end

            5'd19: begin
                row0 = mirror8(8'b11100111);
                row1 = mirror8(8'b11100111);
                row2 = mirror8(8'b11100111);
                row3 = mirror8(8'b11100111);
                row4 = mirror8(8'b11100111);
                row5 = mirror8(8'b11100111);
                row6 = mirror8(8'b11100111);
                row7 = mirror8(8'b11111111);
            end

            // =================================================
            // DEFAULT
            // =================================================
            default: begin
                row0 = 8'b00000000;
                row1 = 8'b00000000;
                row2 = 8'b00000000;
                row3 = 8'b00000000;
                row4 = 8'b00000000;
                row5 = 8'b00000000;
                row6 = 8'b00000000;
                row7 = 8'b00000000;
            end
        endcase
    end

endmodule