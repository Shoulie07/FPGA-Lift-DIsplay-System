// ============================================================
// Module  : debounce
// Fungsi  : Debounce tombol Active LOW
//           Output HIGH selama tombol ditekan
// ============================================================
module debounce (
    input  wire clk,
    input  wire btn_in,
    output reg  btn_out
);

    reg [19:0] cnt;
    reg sync_0, sync_1;
    reg stable;

    initial begin
        cnt     = 20'd0;
        sync_0  = 1'b1;
        sync_1  = 1'b1;
        stable  = 1'b1;
        btn_out = 1'b0;
    end

    // ========================================================
    // Synchronizer
    // ========================================================
    always @(posedge clk) begin
        sync_0 <= btn_in;
        sync_1 <= sync_0;
    end

    // ========================================================
    // Debounce
    // ========================================================
    always @(posedge clk) begin
        if (sync_1 == stable) begin
            cnt <= 10'd0;
        end
        else begin
            if (cnt < 10'd999_999)
                cnt <= cnt + 20'd1;
            else begin
                stable <= sync_1;
                cnt <= 10'd0;
            end
        end
    end

    // ========================================================
    // Output Active HIGH saat tombol ditekan
    // Karena tombol Active LOW
    // ========================================================
    always @(posedge clk) begin
        btn_out <= ~stable;
    end

endmodule