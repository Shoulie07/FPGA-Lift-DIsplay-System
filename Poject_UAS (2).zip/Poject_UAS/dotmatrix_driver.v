// ============================================================
// Module  : dotmatrix_driver
// Fungsi  : Menggerakkan dot matrix 8x8 dengan teknik
//           multiplexing (scanning per baris)
//           Scanning 1kHz → tiap baris aktif ~125us
//           Cukup cepat agar mata tidak melihat kedipan
// ============================================================
module dotmatrix_driver (
    input  wire       clk_1khz,

    // Data bitmap dari frame_rom
    input  wire [7:0] row0,
    input  wire [7:0] row1,
    input  wire [7:0] row2,
    input  wire [7:0] row3,
    input  wire [7:0] row4,
    input  wire [7:0] row5,
    input  wire [7:0] row6,
    input  wire [7:0] row7,

    // Output ke dot matrix
    // ROW  : active HIGH  (anoda baris)
    // COL  : active LOW   (katoda kolom)
    output reg  [7:0] row_sel,
    output reg  [7:0] col_data
);
    reg [2:0] scan_idx;  // index baris yang sedang aktif (0-7)

    initial begin
        scan_idx = 0;
        row_sel  = 8'b00000001;
        col_data = 8'hFF;
    end

    always @(posedge clk_1khz) begin
        scan_idx <= scan_idx + 3'd1;
    end

		// ROW aktif LOW, COL aktif HIGH (tidak di-invert)
		always @(*) begin
			 row_sel = ~(8'b00000001 << scan_idx); // invert ROW
			 case (scan_idx)
				  3'd0: col_data = row0;  // tidak di-invert
				  3'd1: col_data = row1;
				  3'd2: col_data = row2;
				  3'd3: col_data = row3;
				  3'd4: col_data = row4;
				  3'd5: col_data = row5;
				  3'd6: col_data = row6;
				  3'd7: col_data = row7;
				  default: col_data = 8'h00;
			 endcase
		end
endmodule
